import React, { Component } from 'react';
import './AppSass.scss';

class App extends Component {
  render() {
    return <div className="App" />;
  }
}

export default App;
