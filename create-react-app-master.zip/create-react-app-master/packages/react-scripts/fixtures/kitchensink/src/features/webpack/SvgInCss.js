import React from 'react';
import './assets/svg.css';

export default () => <div id="feature-svg-in-css" />;
