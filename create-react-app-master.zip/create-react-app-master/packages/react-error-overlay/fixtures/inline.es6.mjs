function foo() {
  console.log('bar')
}

export { foo }
